export default function Loading() { return <main className="center"><p role="status">Opening ResearchPilot…</p></main>; }
