"use client";
export default function ErrorPage({ reset }: { reset: () => void }) {
  return <main className="center"><section className="card"><h1>We couldn’t open this page</h1><p>Please try again.</p><button onClick={reset}>Try again</button></section></main>;
}
