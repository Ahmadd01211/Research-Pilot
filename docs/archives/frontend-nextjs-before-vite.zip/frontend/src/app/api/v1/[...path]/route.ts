import type { NextRequest } from "next/server";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const allowed: Record<string, string[]> = {
  "auth/csrf": ["GET"], "auth/register": ["POST"], "auth/login": ["POST"],
  "auth/logout": ["POST"], "me": ["GET", "PATCH"], "health/live": ["GET"], "health/ready": ["GET"],
};
async function proxy(request: NextRequest, context: { params: Promise<{ path: string[] }> }) {
  const path = (await context.params).path.join("/");
  if (!allowed[path]?.includes(request.method)) return Response.json({ detail: "Endpoint unavailable" }, { status: 404 });
  const headers = new Headers();
  for (const name of ["cookie", "content-type", "x-csrf-token", "origin"]) {
    const value = request.headers.get(name); if (value) headers.set(name, value);
  }
  const mutating = ["POST", "PATCH"].includes(request.method);
  if (mutating && request.headers.get("origin") !== process.env.APP_ORIGIN) return Response.json({ detail: "Request origin is not allowed" }, { status: 403 });
  let body: string | undefined;
  if (mutating) {
    if (!request.headers.get("content-type")?.startsWith("application/json") && path !== "auth/logout") return Response.json({ detail: "JSON required" }, { status: 415 });
    const reader = request.body?.getReader(); let total = 0; const chunks: Uint8Array[] = [];
    if (reader) { while (true) { const { done, value } = await reader.read(); if (done) break; total += value.byteLength; if (total > 16_384) { await reader.cancel(); return Response.json({ detail: "Request too large" }, { status: 413 }); } chunks.push(value); } }
    body = Buffer.concat(chunks).toString("utf8");
  }
  try {
    const upstream = await fetch(`${process.env.API_INTERNAL_URL}/api/v1/${path}`, { method: request.method, headers, body, cache: "no-store", redirect: "manual", signal: AbortSignal.any([request.signal, AbortSignal.timeout(15_000)]) });
    const outgoing = new Headers({ "cache-control": "no-store" });
    for (const name of ["content-type", "x-request-id", "retry-after"]) { const value = upstream.headers.get(name); if (value) outgoing.set(name, value); }
    for (const value of upstream.headers.getSetCookie()) outgoing.append("set-cookie", value);
    return new Response(upstream.body, { status: upstream.status, headers: outgoing });
  } catch { return Response.json({ detail: "Account service temporarily unavailable" }, { status: 503 }); }
}
export { proxy as GET, proxy as POST, proxy as PATCH };
