export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return <main className="auth-layout"><section className="intro"><a href="/" className="brand">ResearchPilot<span>ACADEMIC RESEARCH WORKSPACE</span></a><div><p className="eyebrow">FROM SOURCES TO SCHOLARSHIP</p><h1>Build your research<br/>on solid evidence.</h1><p>A focused home for your academic work.<br/>Your research journey starts with your account.</p></div><small>Thoughtful research. Traceable evidence.</small></section><section className="auth-content">{children}</section></main>;
}
