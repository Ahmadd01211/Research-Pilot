import { requireUser } from "@/lib/auth/session";
import { ProfileForm } from "@/features/auth/profile-form";
export default async function Profile() {
  const user = await requireUser();
  return <><p className="eyebrow">ACCOUNT SETTINGS</p><h1>Your profile</h1><p className="muted">Manage the name associated with your research account.</p><ProfileForm user={user}/></>;
}
