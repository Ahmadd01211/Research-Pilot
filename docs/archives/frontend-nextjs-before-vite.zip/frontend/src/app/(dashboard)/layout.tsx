import { requireUser } from "@/lib/auth/session";
export default async function WorkspaceLayout({ children }: { children: React.ReactNode }) {
  await requireUser();
  return <div className="workspace"><header><a href="/profile" className="brand">ResearchPilot<span>ACADEMIC RESEARCH WORKSPACE</span></a><span className="badge">Personal workspace</span></header><main className="workspace-main">{children}</main></div>;
}
