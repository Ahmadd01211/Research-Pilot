"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import type { z } from "zod";
import { mutate } from "@/lib/api/client";
import { registerSchema } from "./schemas";

type Values = z.infer<typeof registerSchema>;
export function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter(), [error, setError] = useState("");
  const isRegister = mode === "register";
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<Values>({ resolver: zodResolver(registerSchema), defaultValues: { display_name: isRegister ? "" : "Researcher" } });
  async function submit(data: Values) {
    setError("");
    try {
      if (isRegister) await mutate("/auth/register", "POST", data);
      await mutate("/auth/login", "POST", { email: data.email, password: data.password });
      router.replace("/profile"); router.refresh();
    } catch (failure) { setError(failure instanceof Error ? failure.message : "Please try again"); }
  }
  return <div className="auth-card"><p className="eyebrow">YOUR RESEARCH STARTS HERE</p><h2>{isRegister ? "Create your account" : "Welcome back"}</h2><p className="muted">{isRegister ? "Set up your personal research workspace." : "Sign in to your ResearchPilot account."}</p>
    <form onSubmit={handleSubmit(submit)} noValidate>
      {isRegister && <label>Full name<input autoComplete="name" {...register("display_name")} aria-invalid={!!errors.display_name} aria-describedby="name-error"/><small id="name-error" className="field-error">{errors.display_name?.message}</small></label>}
      <label>Email address<input type="email" autoComplete="email" {...register("email")} aria-invalid={!!errors.email} aria-describedby="email-error"/><small id="email-error" className="field-error">{errors.email?.message}</small></label>
      <label>Password<input type="password" autoComplete={isRegister ? "new-password" : "current-password"} {...register("password")} aria-invalid={!!errors.password} aria-describedby="password-error"/><small id="password-error" className="field-error">{errors.password?.message || (isRegister ? "Use at least 12 characters." : "")}</small></label>
      {error && <p role="alert" className="alert">{error}</p>}
      <button type="submit" disabled={isSubmitting}>{isSubmitting ? "Please wait…" : isRegister ? "Create account" : "Sign in"}</button>
    </form><p className="switch">{isRegister ? "Already have an account?" : "New to ResearchPilot?"} <Link href={isRegister ? "/login" : "/register"}>{isRegister ? "Sign in" : "Create an account"}</Link></p>
  </div>;
}
