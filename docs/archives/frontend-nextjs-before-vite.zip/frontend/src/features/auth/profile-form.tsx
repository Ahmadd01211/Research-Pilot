"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { mutate, type User } from "@/lib/api/client";
import { profileSchema } from "./schemas";
export function ProfileForm({ user }: { user: User }) {
  const router = useRouter(), [error, setError] = useState(""), [notice, setNotice] = useState(""), [loggingOut, setLoggingOut] = useState(false);
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(profileSchema), defaultValues: { display_name: user.display_name } });
  async function save(data: { display_name: string }) {
    setError(""); setNotice("");
    try { await mutate("/me", "PATCH", data); setNotice("Your profile has been saved."); router.refresh(); }
    catch (failure) { setError(failure instanceof Error ? failure.message : "Unable to save"); }
  }
  async function logout() {
    setLoggingOut(true); setError("");
    try { await mutate("/auth/logout", "POST"); router.replace("/login"); router.refresh(); }
    catch (failure) { setError(failure instanceof Error ? failure.message : "Unable to sign out"); setLoggingOut(false); }
  }
  return <section className="card profile-card"><h2>Personal information</h2><p className="muted">{user.email}</p><form onSubmit={handleSubmit(save)} noValidate><label>Display name<input autoComplete="name" {...register("display_name")} aria-invalid={!!errors.display_name} aria-describedby="name-error"/><small id="name-error" className="field-error">{errors.display_name?.message}</small></label>{error && <p role="alert" className="alert">{error}</p>}{notice && <p role="status" className="notice">{notice}</p>}<button disabled={isSubmitting || loggingOut}>{isSubmitting ? "Saving…" : "Save changes"}</button></form><div className="signout"><div><h3>End this session</h3><p className="muted">Sign out securely on this device.</p></div><button className="secondary" onClick={logout} disabled={loggingOut || isSubmitting}>{loggingOut ? "Signing out…" : "Sign out"}</button></div></section>;
}
