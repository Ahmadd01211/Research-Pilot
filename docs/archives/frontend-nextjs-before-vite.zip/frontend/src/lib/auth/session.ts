import "server-only";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import type { User } from "@/lib/api/client";
export async function requireUser(): Promise<User> {
  const response = await fetch(`${process.env.API_INTERNAL_URL}/api/v1/me`, { headers: { cookie: (await cookies()).toString() }, cache: "no-store" });
  if (response.status === 401) redirect("/login");
  if (!response.ok) throw new Error("Account service unavailable");
  return response.json() as Promise<User>;
}
