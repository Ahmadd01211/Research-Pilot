import type { components } from "./schema";
export type User = components["schemas"]["UserRead"];
type Json = Record<string, unknown>;
export class ApiError extends Error { constructor(message: string, public status: number) { super(message); } }
async function decode<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new ApiError(typeof body.detail === "string" ? body.detail : "The request could not be completed", response.status);
  }
  return response.status === 204 ? undefined as T : response.json() as Promise<T>;
}
export async function mutate<T>(path: string, method: "POST" | "PATCH", body?: Json): Promise<T> {
  const token = await decode<{ csrf_token: string }>(await fetch("/api/v1/auth/csrf", { cache: "no-store" }));
  return decode<T>(await fetch(`/api/v1${path}`, { method, headers: { "content-type": "application/json", "x-csrf-token": token.csrf_token }, body: body ? JSON.stringify(body) : undefined }));
}
